# Chatbot Frontend

This project contains the frontend components for a chatbot application. It includes the HTML structure, JavaScript logic for interacting with a chatbot API, a minified version of the JavaScript for production, and a logo image.

---

##  File Structure

- **`index.html`**
  - **Purpose**: Serves as the basic HTML shell for locally check the `chatbot.js`.
  - **Functionality**: Loads the `chatbot.js` file, which dynamically generates the chatbot interface.

    ```<script src="http://127.0.0.1:5001/static/chatbot.js" data-tenant-id="681dae273d1925918ab803ed"></script>```


- **`chatbot.js`**
  - **Purpose**: Contains the main JavaScript logic to render the chatbot UI and manage user interactions.
  - See Chatbot Frontend Process Flow below for details.

- **`minify.js`**
  - **Purpose**: A minified version of `chatbot.js`.
  - **Functionality**: Optimized for production—smaller file size and faster loading.

- **`logo.jpeg`**
  - **Purpose**: Branding asset for the chatbot interface.
  - **Usage**: Displayed in UI, referenced by `chatbot.js`.

---

## 🔁 Chatbot Frontend Process Flow


### Process Steps:

1. **Extract `tenant_id`** from the `<script>` tag.
2. **Fetch configuration** (bot name, welcome message, theme) using the `tenant_id` from backend.

[//]: # (3. **Prompt user** for name and email &#40;optional&#41;.)

[//]: # (4. **Send user details** to backend and receive `user_id` and `session_id`.)

[//]: # (5. **Render chat interface** and manage message display &#40;user & bot&#41;.)

[//]: # (6. **On reload**, fetch `user_id` and `session_id` from localStorage and continue previous conversation.)

[//]: # (7. **On refresh**, reset session: clear conversation and get a new `session_id`.)

[//]: # (8. **If localStorage is cleared**, generate a new `user_id` and `session_id`, and prompt the user again.)

---

## Development

1. Edit `chatbot.js` for logic, appearance, or feature changes and Set correct backend API URLs in `chatbot.js`..
2. Re-minify it using a minification tool like  [minifier](https://www.toptal.com/developers/javascript-minifier) and save the minified code in `minify.js`.
3. Use `minify.js` for production to ensure faster loading times.

---
