const LuraChat = (function() {
    const CONFIG = {
        apiEndpoint: "http://127.0.0.1:5002",
        inactivityTimeout: 10 * 60 * 1000,
        errorMessage: "Sorry, I'm having trouble connecting. Please try again later.",
        logoUrl: 'logo.jpeg',
        clearOnReload: false, // Changed to false to maintain history
        statusCheckInterval: 30000, // Check status every 30 seconds
        isActive: false, // Track bot active status
        welcomeMessage: null // Add this line
    };

    const STORAGE_KEYS = {
        history: "lura_chat_history",
        lastActive: "lura_last_active",
        initialized: "lura_initialized",
        pageLoadId: "lura_page_load_id"
    };

    const THEME_COLORS = {
        white: {
            '--primary-color': '#0000000',
            '--primary-gradient': 'linear-gradient(45deg, #ffffff, #f8fafc)',
            '--text-color': '#000000',
            '--bubble-sent': '#000000',
            '--bubble-received': '#00000',
            '--background-color': '#ffffff'
        },
        black: {
            '--primary-color': '#111827',
            '--primary-gradient': 'linear-gradient(45deg, #1f2937, #374151)',
            '--text-color': '#e5e7eb',
            '--bubble-sent': '#4b5563',
            '--bubble-received': '#1e293b',
            '--background-color': '#0f172a'
        },
        orange: {
            '--primary-color': '#f97316',
            '--primary-gradient': 'linear-gradient(45deg, #f97316, #ea580c)',
            '--text-color': '#000000',
            '--bubble-sent': '#ea580c',
            '--bubble-received': '#ffedd5',
            '--background-color': '#fff7ed'
        },
        yellow: {
            '--primary-color': '#fbbf24',
            '--primary-gradient': 'linear-gradient(45deg, #fbbf24, #f59e0b)',
            '--text-color': '#4b5563',
            '--bubble-sent': '#f59e0b',
            '--bubble-received': '#fef3c7',
            '--background-color': '#fffbeb'
        },
        red: {
            '--primary-color': '#ef4444',
            '--primary-gradient': 'linear-gradient(45deg, #ef4444, #dc2626)',
            '--text-color': '#00000',
            '--bubble-sent': '#dc2626',
            '--bubble-received': '#fee2e2',
            '--background-color': '#fef2f2'
        },
        green: {
            '--primary-color': '#22c55e',
            '--primary-gradient': 'linear-gradient(45deg, #22c55e, #16a34a)',
            '--text-color': '#1e293b',
            '--bubble-sent': '#059669',
            '--bubble-received': '#d1fae5',
            '--background-color': '#f0fdf4'
        },
        blue: {
            '--primary-color': '#1e90ff',
            '--primary-gradient': 'linear-gradient(45deg, #1e90ff, #00bfff)',
            '--text-color': '#333',
            '--bubble-sent': '#007bff',
            '--bubble-received': '#f1f5f9',
            '--background-color': '#f5f7fa'
        }
    };

    let elements = {};

    async function fetchBotConfig(tenantId) {
        try {
            console.log(`Fetching bot config for tenant: ${tenantId}`);
            console.log(`Request URL: ${CONFIG.apiEndpoint}/bot-config/${tenantId}`);
            const response = await fetch(`${CONFIG.apiEndpoint}/bot-config/${tenantId}`);
            console.log('Response status:', response.status);
            if (!response.ok) {
                const errorText = await response.text();
                console.error('Error response:', errorText);
                throw new Error(`Failed to fetch bot configuration: ${response.status}`);
            }
            const config = await response.json();
            console.log('Received config:', config);
            if (!config.bot_name || !config.welcome_message) {
                throw new Error('Invalid bot configuration: missing required fields');
            }
            CONFIG.welcomeMessage = config.welcome_message;
            CONFIG.botName = config.bot_name;
            return config;
        } catch (error) {
            console.error('Error in fetchBotConfig:', error);
            throw error;
        }
    }

    // Add status checking function
    async function checkBotStatus(tenantId) {
        try {
            const response = await fetch(`${CONFIG.apiEndpoint}/bot-status/${tenantId}`);
            if (!response.ok) throw new Error("Failed to check bot status");
            const data = await response.json();
            CONFIG.isActive = data.status === "active";
            // Update UI based on status
            if (!CONFIG.isActive && !elements.chatContainer.classList.contains("lura-d-none")) {
                closeChat();
            }
            return CONFIG.isActive;
        } catch (error) {
            console.error("Error checking bot status:", error);
            return false;
        }
    }

    async function init(config = {}) {
        const scriptTag = document.querySelector('script[data-tenant-id]');
        const tenantId = scriptTag?.getAttribute('data-tenant-id');
        if (!tenantId) {
            console.error('No tenant ID provided');
            return;
        }
        try {
            // Initial status check
            await checkBotStatus(tenantId);
            
            // Fetch bot configuration first before anything else
            const botConfig = await fetchBotConfig(tenantId);
            console.log('Full bot config received:', botConfig);
            
            // Store config values immediately
            CONFIG.welcomeMessage = botConfig.welcome_message;
            CONFIG.botName = botConfig.bot_name;
            
            // Start periodic status checking
            setInterval(() => checkBotStatus(tenantId), CONFIG.statusCheckInterval);
            
            // Setup theme
            const colorTheme = botConfig.color_theme?.toLowerCase() || 'blue';
            const theme = THEME_COLORS[colorTheme] || THEME_COLORS.blue;
            
            // Apply theme
            const themeStyle = document.createElement('style');
            themeStyle.textContent = `
                :root {
                    ${Object.entries(theme).map(([property, value]) => `${property}: ${value};`).join('\n                ')}
                }
            `;
            document.head.appendChild(themeStyle);
            
            // Initialize UI
            Object.assign(CONFIG, config);
            injectStyles();
            createChatElements();
            cacheElements();
            bindEvents();
            
            // Don't show welcome message immediately, let loadChatHistory handle it
            elements.chatBody.innerHTML = "";
            loadChatHistory();
            
        } catch (error) {
            console.error('Failed to initialize chat:', error);
        }
    }

    function checkAndClearOnReload() {
        const currentLoadId = Date.now().toString();
        const previousLoadId = safeGetStorage(STORAGE_KEYS.pageLoadId, '');
        safeSetStorage(STORAGE_KEYS.pageLoadId, currentLoadId);
        if (previousLoadId) {
            resetChatHistory();
            console.log("Page reloaded: Chat history cleared");
        }
    }

    // Update injectStyles to remove hardcoded color from chat button
    function injectStyles() {
        const styleElement = document.createElement('style');
        styleElement.textContent = `
            .lura-widget * {
                box-sizing: border-box;
            }
            .lura-widget p {
                margin: 0;
                padding: 0;
            }
            .lura-chat-icon {
                position: fixed;
                bottom: 75px;
                right: 17px;
                width: 50px;
                height: 50px;
                /* Remove default theme color */
                color: white;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                z-index: 999;
                transition: transform 0.3s ease;
            }
            .lura-chat-icon:hover {
                transform: scale(1.1);
            }
            .lura-chat-container {
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 350px;
                height: 500px;
                background: white;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                display: flex;
                flex-direction: column;
                overflow: hidden;
                z-index: 1000;
                transition: all 0.3s ease;
                border-radius: 10px;
                font-family: 'Poppins', sans-serif, Arial;
            }
            .lura-chat-button {
                background-color: var(--primary-color);
                border: none;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
                transition: background-color 0.3s ease;
                outline: none;
            }
            .lura-chat-button:focus {
                outline: none;
                box-shadow: none;
            }
            .lura-chat-button:hover {
                opacity: 0.9; /* Change from hardcoded color to use opacity */
            }
            .lura-chat-button svg {
                stroke: white;
            }
            .lura-chat-header {
                background: var(--primary-gradient);
                padding: 15px;
                color: white;
                display: flex;
                align-items: center;
                gap: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
            }
            .lura-chat-header strong {
                font-size: 20px;
                font-weight: 500;
                display: block;
                margin-bottom: 2px;
            }
            .lura-chat-header img {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                border: 2px solid white;
            }
            .lura-close-btn {
                background: transparent;
                border: none;
                color: white;
                font-size: 14px;
                padding: 5px 10px;
                cursor: pointer;
                margin-left: auto;
                outline: none;
            }
            .lura-close-btn:focus {
                outline: none;
                box-shadow: none;
            }
            .lura-chat-body {
                flex: 1;
                padding: 15px;
                overflow-y: auto;
                scrollbar-width: none;
                -ms-overflow-style: none;
                display: flex;
                flex-direction: column;
            }
            .lura-chat-body::-webkit-scrollbar {
                display: none;
            }
            .lura-chat-bubble {
                max-width: 80%;
                padding: 10px;
                opacity: 0;
                animation: lura-fadeInUp 0.5s ease-out forwards;
                border-radius: 12px;
                margin: 5px 0;
            }
            .lura-chat-bubble.sent {
                background: var(--bubble-sent);
                color: white;
                align-self: flex-end;
                margin-left: auto;
                font-size: 13px;
                border-bottom-right-radius: 0;
                word-wrap: break-word;
                overflow-wrap: break-word;
                white-space: normal;
            }
            .lura-chat-bubble.received {
                background: var(--bubble-received);
                color: var(--text-color);
                align-self: flex-start;
                text-align: left;
                font-size: 13px;
                border-top-left-radius: 0;
                overflow-wrap: break-word;
                word-wrap: break-word;
                word-break: break-word;
                max-width: 80%;
            }
            .lura-chat-bubble ol,
            .lura-chat-bubble ul {
                padding-left: 20px;
                margin: 5px 0;
            }
            .lura-chat-bubble li {
                margin-bottom: 3px;
            }
            .lura-chat-bubble p {
                margin-bottom: 8px;
            }
            .lura-chat-footer {
                display: flex;
                align-items: center;
                padding: 10px;
                border-top: 1px solid #ddd;
                position: relative;
                font-size: 13px;
            }
            .lura-chat-footer input {
                flex: 1;
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 10px;
                background: #f1f1f1;
                outline: none;
                font-family: 'Poppins', sans-serif, Arial;
            }
            .lura-send-button {
                background: var(--primary-color);
                border: none;
                color: white;
                border-radius: 10px;
                cursor: pointer;
                width: 40px;
                height: 40px;
                min-width: 40px;
                min-height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-left: 10px;
                position: relative;
                z-index: 10;
                transition: transform 0.2s ease;
            }
            .lura-send-button:hover {
                transform: scale(1.05);
            }
            .lura-typing-indicator {
                display: flex;
                align-items: center;
                padding: 8px 12px;
                background: #f1f1f1;
                border-radius: 15px;
                width: fit-content;
                margin-bottom: 8px;
                align-self: flex-start;
            }
            .lura-typing-indicator span {
                width: 6px;
                height: 6px;
                margin: 0 2px;
                background: gray;
                border-radius: 50%;
                display: inline-block;
                animation: lura-typing 1.2s infinite ease-in-out;
            }
            .lura-typing-indicator span:nth-child(1) {
                animation-delay: 0s;
            }
            .lura-typing-indicator span:nth-child(2) {
                animation-delay: 0.2s;
            }
            .lura-typing-indicator span:nth-child(3) {
                animation-delay: 0.4s;
            }
            .lura-ms-auto {
                margin-left: auto !important;
            }
            .lura-d-none {
                display: none !important;
            }
            @keyframes lura-typing {
                0% {
                    transform: translateY(0px);
                    opacity: 0.3;
                }
                50% {
                    transform: translateY(-5px);
                    opacity: 1;
                }
                100% {
                    transform: translateY(0px);
                    opacity: 0.3;
                }
            }
            @keyframes lura-fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            @media screen and (max-width: 480px) {
                .lura-chat-container {
                    width: 90%;
                    height: 80%;
                    bottom: 10%;
                    right: 5%;
                }
                .lura-chat-header strong {
                    font-size: 16px;
                }
                .lura-chat-header img {
                    width: 32px;
                    height: 32px;
                }
                .lura-chat-footer {
                    padding: 8px;
                }
                .lura-chat-footer input {
                    padding: 8px;
                    font-size: 14px;
                }
                .lura-send-button {
                    width: 36px;
                    height: 36px;
                    min-width: 36px;
                    min-height: 36px;
                }
                .lura-chat-bubble {
                    padding: 8px 12px;
                    font-size: 14px;
                }
            }
            .lura-status-bubble {
                position: fixed;
                bottom: 140px;
                right: 20px;
                background: var(--background-color);
                color: var(--text-color);
                padding: 15px 20px;
                border-radius: 10px;
                font-size: 14px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                animation: lura-fadeInUp 0.3s ease-out forwards;
                z-index: 1000;
                font-family: 'Poppins', sans-serif, Arial;
                max-width: 280px;
                display: flex;
                flex-direction: column;
                gap: 4px;  // Reduced from 8px
            }
            .lura-status-bubble h4 {
                margin: 0 0 2px;  // Added small bottom margin
                font-size: 15px;  // Added small bottom margin
                font-weight: 600;
                color: var(--text-color);
            }
            .lura-status-bubble p {
                margin: 0;
                font-size: 13px;
                line-height: 1.4;
                color: var(--text-color);
                opacity: 0.8;
            }
            .lura-status-bubble::before {
                content: '';
                position: absolute;
                bottom: -8px;
                right: 24px;
                width: 0;
                height: 0;
                border-left: 8px solid transparent;
                border-right: 8px solid transparent;
                border-top: 8px solid var(--background-color);
            }
            .lura-skip-button {
                background: transparent;
                border: 1px solid var(--primary-color);
                color: var(--primary-color);
                border-radius: 10px;
                padding: 8px 16px;
                margin-right: 8px;
                cursor: pointer;
                font-size: 13px;
                transition: all 0.2s ease;
            }
            .lura-skip-button:hover {
                background: var(--primary-color);
                color: white;
            }
            .lura-header-actions {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-left: auto;
            }
            .lura-refresh-btn, .lura-minimize-btn {
                background: transparent;
                border: none;
                color: white;
                padding: 5px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                transition: background-color 0.2s;
            }
            .lura-refresh-btn:hover, .lura-minimize-btn:hover {
                background: rgba(255, 255, 255, 0.1);
            }
            .lura-refresh-btn svg, .lura-minimize-btn svg {
                width: 16px;
                height: 16px;
            }
            .lura-powered-by {
                padding: 8px;
                text-align: center;
                font-size: 11px;
                color: #666;
                border-top: 1px solid #eee;
                background: #f8f9fa;
                font-family: 'Poppins', sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
            }
            
            .lura-powered-by img {
                height: 15px;
                width: auto;
                vertical-align: middle;
            }
            
            .lura-powered-by a {
                color: var(--primary-color);
                text-decoration: none;
                display: flex;
                align-items: center;
                gap: 4px;
            }
            
            @media screen and (max-width: 480px) {
                .lura-powered-by {
                    font-size: 10px;
                    padding: 6px;
                }
                .lura-powered-by img {
                    height: 12px;
                }
            }
        `;
        document.head.appendChild(styleElement);

        if (!document.querySelector('link[href*="font-awesome"]')) {
            const fontAwesome = document.createElement('link');
            fontAwesome.rel = 'stylesheet';
            fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
            document.head.appendChild(fontAwesome);
        }

        if (!document.querySelector('link[href*="poppins"]')) {
            const poppinsFont = document.createElement('link');
            poppinsFont.rel = 'stylesheet';
            poppinsFont.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap';
            document.head.appendChild(poppinsFont);
        }
    }

    // Update createChatElements to explicitly set the background color
    function createChatElements() {
        const widgetContainer = document.createElement('div');
        widgetContainer.className = 'lura-widget';
        document.body.appendChild(widgetContainer);

        const chatIcon = document.createElement('div');
        chatIcon.className = 'lura-chat-icon';
        chatIcon.id = 'luraChatIcon';
        chatIcon.style.backgroundColor = 'var(--primary-color)';
        chatIcon.innerHTML = `
            <button class="lura-chat-button">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2z"></path>
                </svg>
            </button>`;
        widgetContainer.appendChild(chatIcon);

        const chatContainer = document.createElement('div');
        chatContainer.className = 'lura-chat-container lura-d-none';
        chatContainer.id = 'luraChatContainer';

        const chatHeader = document.createElement('div');
        chatHeader.className = 'lura-chat-header';
        chatHeader.innerHTML = `
            <div>
                <strong id="botNameDisplay">${CONFIG.botName}</strong>
                <p style="font-size: 12px; opacity: 0.8;">We are online!</p>
            </div>
            <div class="lura-header-actions">
                <button class="lura-refresh-btn" id="luraRefreshBtn" title="Clear chat history">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 2v6h-6"></path>
                        <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
                        <path d="M3 12a9 9 0 0 0 15 6.7L21 16"></path>
                    </svg>
                </button>
                <button class="lura-minimize-btn" id="luraMinimizeBtn" title="Minimize chat">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </button>
            </div>
        `;
        chatContainer.appendChild(chatHeader);

        const chatBody = document.createElement('div');
        chatBody.className = 'lura-chat-body';
        chatBody.id = 'luraChatBody';
        chatContainer.appendChild(chatBody);

        const chatFooter = document.createElement('div');
        chatFooter.className = 'lura-chat-footer';
        chatFooter.innerHTML = `
            <input type="text" id="luraUserInput" placeholder="Enter your message...">
            <button class="lura-send-button" id="luraSendBtn">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 2L15 22L11 13L2 9L22 2Z"></path>
                </svg>
            </button>
        `;
        chatContainer.appendChild(chatFooter);

        // Add powered by bar with logo
        const poweredBy = document.createElement('div');
        poweredBy.className = 'lura-powered-by';
        poweredBy.innerHTML = `Powered by <a href="https://aaludra.com" target="_blank" rel="noopener noreferrer">
            <img src="https://aaludra.com/wp-content/uploads/elementor/thumbs/Frame-1000002086-r5pcddm9wd0v6ze1slcgc19e6jb0is2689vkk3au08.png" alt="Aaludra">
        </a>`;
        chatContainer.appendChild(poweredBy);

        widgetContainer.appendChild(chatContainer);
    }

    function cacheElements() {
        elements = {
            chatIcon: document.getElementById("luraChatIcon"),
            chatContainer: document.getElementById("luraChatContainer"),
            chatBody: document.getElementById("luraChatBody"),
            userInput: document.getElementById("luraUserInput"),
            sendBtn: document.getElementById("luraSendBtn"),
            closeBtn: document.getElementById("luraCloseBtn"),
            refreshBtn: document.getElementById("luraRefreshBtn"),
            minimizeBtn: document.getElementById("luraMinimizeBtn")
        };
    }

    function bindEvents() {
        elements.chatIcon.addEventListener("click", openChat);
        elements.refreshBtn.addEventListener("click", handleRefresh);
        elements.minimizeBtn.addEventListener("click", minimizeChat);
        elements.sendBtn.addEventListener("click", handleSendMessage);
        
        // Fix Enter key handling
        elements.userInput.addEventListener("keydown", function(event) {
            if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault(); // Prevent default to avoid newline
                handleSendMessage();
            }
        });
        
        // Remove beforeunload event listener to maintain history
        if (CONFIG.clearOnReload) {
            window.removeEventListener('beforeunload', resetChatHistory);
        }
    }

    function initializeChat() {
        elements.chatBody.innerHTML = "";
        const chatHistory = getChatHistory();
        if (!chatHistory || chatHistory.length === 0) {
            showWelcomeMessage();
        } else {
            loadChatHistory();
        }
    }

    async function sendInitialRequest() {
        let typingIndicator = null;
        try {
            const scriptTag = document.querySelector('script[data-tenant-id]');
            const tenantId = scriptTag?.getAttribute('data-tenant-id');

            if (!tenantId) {
                throw new Error("Tenant ID not found");
            }

            typingIndicator = showTypingIndicator();

            const response = await fetch(`${CONFIG.apiEndpoint}/chat`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Tenant-ID": tenantId
                },
                body: JSON.stringify({
                    type: "chat",
                    tenant_id: tenantId
                })
            });

            if (!response.ok) {
                throw new Error("Server error");
            }

            const data = await response.json();
            if (data.user_id) {
                safeSetStorage(STORAGE_KEYS.userId, data.user_id);
                const assistantBubble = addMessageBubble("assistant", data.response);
                saveMessage("assistant", data.response);
            }

        } catch (error) {
            console.error("Error:", error);
            addMessageBubble("assistant", CONFIG.errorMessage);
        } finally {
            if (typingIndicator) {
                removeTypingIndicator(typingIndicator);
            }
            elements.userInput.disabled = false;
            elements.sendBtn.disabled = false;
            elements.userInput.focus();
        }
    }

    function openChat() {
        if (!CONFIG.isActive) {
            const messageBubble = document.createElement("div");
            messageBubble.className = "lura-status-bubble";
            messageBubble.innerHTML = `
                <h4>Training in Progress</h4>
                <p>The AI is still training with the data. Please wait a few minutes...</p>`;
            document.body.appendChild(messageBubble);
            setTimeout(() => {
                if (messageBubble.parentNode === document.body) {
                    messageBubble.remove();
                }
            }, 3000);
            return;
        }

        elements.chatContainer.classList.remove("lura-d-none");
        elements.chatIcon.classList.add("lura-d-none");
        
        loadChatHistory(); // Always load chat history first
        setTimeout(() => elements.userInput.focus(), 100);
    }

    function closeChat() {
        elements.chatContainer.classList.add("lura-d-none");
        elements.chatIcon.classList.remove("lura-d-none");
    }

    function loadChatHistory() {
        elements.chatBody.innerHTML = "";
        try {
            checkInactivityTimeout();
            const chatHistory = getChatHistory();
            if (!chatHistory || chatHistory.length === 0) {
                // Only show welcome message if there's no history
                showWelcomeMessage();
            } else {
                displayChatHistory(chatHistory);
            }
            scrollToBottom();
        } catch (error) {
            console.error("Error loading chat history:", error);
            showWelcomeMessage();
        }
    }

    function safeGetStorage(key, defaultValue) {
        try {
            const value = localStorage.getItem(key);
            return value === null ? defaultValue : value;
        } catch (error) {
            console.error("Error accessing localStorage:", error);
            return defaultValue;
        }
    }

    function safeSetStorage(key, value) {
        try {
            localStorage.setItem(key, value);
            return true;
        } catch (error) {
            console.error("Error setting localStorage:", error);
            return false;
        }
    }

    // Update localStorage handling for user data persistence
    function checkInactivityTimeout() {
        const lastActiveTime = parseInt(safeGetStorage(STORAGE_KEYS.lastActive, "0"));
        const currentTime = Date.now();

        if (currentTime - lastActiveTime > CONFIG.inactivityTimeout) {
            resetChatHistory(); // Only clear chat history, not user data
        }
        updateLastActiveTime();
    }

    function getChatHistory() {
        return JSON.parse(safeGetStorage(STORAGE_KEYS.history, "[]"));
    }

    function displayChatHistory(history) {
        history.forEach(msg => {
            const chatBubble = document.createElement("div");
            chatBubble.className = `lura-chat-bubble ${msg.role === "user" ? "sent" : "received"}`;

            if (msg.role === "user") {
                chatBubble.textContent = msg.content;
            } else {
                chatBubble.innerHTML = msg.content;
            }

            elements.chatBody.appendChild(chatBubble);
        });
    }

    function showWelcomeMessage() {
        console.log('Showing welcome message:', CONFIG.welcomeMessage); // Add debug log
        
        if (!CONFIG.welcomeMessage) {
            console.warn("Welcome message not set");
            return;
        }
        
        const welcomeBubble = document.createElement("div");
        welcomeBubble.className = "lura-chat-bubble received";
        welcomeBubble.innerHTML = CONFIG.welcomeMessage;
        
        if (elements.chatBody) {
            elements.chatBody.appendChild(welcomeBubble);
            saveMessage("assistant", CONFIG.welcomeMessage);
            scrollToBottom();
        } else {
            console.error("Chat body element not found");
        }
    }

    // Update reset function to preserve user ID
    function resetChatHistory() {
        try {
            safeSetStorage(STORAGE_KEYS.history, "[]");
            safeSetStorage(STORAGE_KEYS.initialized, "false");
            // Don't clear user ID or last active time
        } catch (error) {
            console.error("Error resetting chat history:", error);
        }
    }

    function updateLastActiveTime() {
        safeSetStorage(STORAGE_KEYS.lastActive, Date.now().toString());
    }

    function saveMessage(role, content) {
        try {
            const chatHistory = getChatHistory();
            chatHistory.push({ role, content });
            safeSetStorage(STORAGE_KEYS.history, JSON.stringify(chatHistory));
            updateLastActiveTime();
        } catch (error) {
            console.error("Error saving message:", error);
        }
    }

    function addMessageBubble(role, content) {
        const bubble = document.createElement("div");
        bubble.className = `lura-chat-bubble ${role === "user" ? "sent" : "received"}`;
        
        if (role === "user") {
            bubble.textContent = content;
        } else {
            bubble.innerHTML = content;
            // Add click handler for skip link
            const skipLink = bubble.querySelector('.skip-name-link');
            if (skipLink) {
                skipLink.onclick = (e) => {
                    e.preventDefault();
                    const input = document.getElementById('luraUserInput');
                    input.value = 'skip';
                    handleSendMessage();
                };
            }
        }
        
        elements.chatBody.appendChild(bubble);
        scrollToBottom();
        return bubble;
    }

    function showTypingIndicator() {
        const typingBubble = document.createElement("div");
        typingBubble.className = "lura-typing-indicator";
        typingBubble.innerHTML = `<span></span><span></span><span></span>`;
        elements.chatBody.appendChild(typingBubble);
        scrollToBottom();
        return typingBubble;
    }

    function scrollToBottom() {
        elements.chatBody.scrollTop = elements.chatBody.scrollHeight;
    }

    // Add skip button functionality
    function addSkipButton() {
        const skipBtn = document.createElement('button');
        skipBtn.textContent = 'Skip';
        skipBtn.className = 'lura-skip-button';
        skipBtn.onclick = () => {
            const input = document.getElementById('luraUserInput');
            input.value = 'skip';
            handleSendMessage();
        };
        elements.chatFooter.insertBefore(skipBtn, elements.sendBtn);
    }

    function removeSkipButton() {
        const skipBtn = document.querySelector('.lura-skip-button');
        if (skipBtn) skipBtn.remove();
    }

    async function handleSendMessage() {
        const message = elements.userInput.value.trim();
        if (message === "") return;

        elements.userInput.disabled = true;
        elements.sendBtn.disabled = true;

        // Regular chat flow
        addMessageBubble("user", message);
        saveMessage("user", message);
        elements.userInput.value = "";

        const typingIndicator = showTypingIndicator();
        await sendMessageToServer(message, typingIndicator);
    }

    async function sendMessageToServer(message, typingIndicator) {
        try {
            const chatHistory = getChatHistory();
            const scriptTag = document.querySelector('script[data-tenant-id]');
            const tenantId = scriptTag?.getAttribute('data-tenant-id');

            const response = await fetch(`${CONFIG.apiEndpoint}/chat`, {
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "X-Tenant-ID": tenantId
                },
                body: JSON.stringify({
                    message: message,
                    history: chatHistory,
                    tenant_id: tenantId
                })
            });

            if (!response.ok) throw new Error("Server error");

            const data = await response.json();
            
            if (typingIndicator) {
                removeTypingIndicator(typingIndicator);
            }

            // Handle multiple messages with typing effect
            if (data.is_multi_response && Array.isArray(data.response)) {
                for (let i = 0; i < data.response.length; i++) {
                    // Add typing indicator between messages
                    if (i > 0) {
                        const msgTypingIndicator = showTypingIndicator();
                        await new Promise(resolve => setTimeout(resolve, 500)); // Short delay
                        removeTypingIndicator(msgTypingIndicator);
                    }
                    
                    const bubble = addMessageBubble("assistant", data.response[i]);
                    saveMessage("assistant", data.response[i]);
                    
                    // Handle links in each bubble
                    const links = bubble.querySelectorAll('a');
                    links.forEach(link => {
                        if (!link.getAttribute('target')) {
                            link.setAttribute('target', '_blank');
                            link.setAttribute('rel', 'noopener noreferrer');
                        }
                    });
                    
                    // Add delay between messages for natural flow
                    if (i < data.response.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 800));
                    }
                }
            } else {
                // Handle single response as before
                const bubble = addMessageBubble("assistant", data.response);
                saveMessage("assistant", data.response);
                
                const links = bubble.querySelectorAll('a');
                links.forEach(link => {
                    if (!link.getAttribute('target')) {
                        link.setAttribute('target', '_blank');
                        link.setAttribute('rel', 'noopener noreferrer');
                    }
                });
            }

        } catch (error) {
            console.error("Error:", error);
            removeTypingIndicator(typingIndicator);
            addMessageBubble("assistant", CONFIG.errorMessage);
            saveMessage("assistant", CONFIG.errorMessage);
        } finally {
            elements.userInput.disabled = false;
            elements.sendBtn.disabled = false;
            elements.userInput.focus();
        }
    }

    function removeTypingIndicator(indicator) {
        if (indicator && indicator.parentNode === elements.chatBody) {
            elements.chatBody.removeChild(indicator);
        }
    }

    function setLogo(logoUrl) {
        if (!logoUrl) return;

        const logoImg = document.querySelector('.lura-chat-header img');
        if (logoImg) {
            logoImg.src = logoUrl;
            CONFIG.logoUrl = logoUrl;
        }
    }

    function handleRefresh() {
        resetChatHistory();
        elements.chatBody.innerHTML = "";
        showWelcomeMessage();
    }

    function minimizeChat() {
        elements.chatContainer.classList.add("lura-d-none");
        elements.chatIcon.classList.remove("lura-d-none");
        // Don't reset chat history on minimize
    }

    return {
        init,
        setConfig: function(config) {
            Object.assign(CONFIG, config);
            if (config.logoUrl) setLogo(config.logoUrl);
        },
        setLogo,
        setApiEndpoint: function(endpoint) {
            CONFIG.apiEndpoint = endpoint;
        },
        setWelcomeMessage: function(message) {
            CONFIG.welcomeMessage = message;
        },
        clearHistory: resetChatHistory,
        open: openChat,
        close: closeChat,
        setClearOnReload: function(enabled) {
            CONFIG.clearOnReload = enabled;
        }
    };
})();

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => LuraChat.init());
} else {
    LuraChat.init();
}