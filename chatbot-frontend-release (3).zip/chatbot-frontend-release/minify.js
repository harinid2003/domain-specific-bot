const LuraChat=function(){let e={apiEndpoint:"http://127.0.0.1:5002",inactivityTimeout:6e5,errorMessage:"Sorry, I'm having trouble connecting. Please try again later.",logoUrl:"logo.jpeg",clearOnReload:!0,statusCheckInterval:3e4,isActive:!1},t={history:"lura_chat_history",lastActive:"lura_last_active",initialized:"lura_initialized",pageLoadId:"lura_page_load_id"},r={white:{"--primary-color":"#0000000","--primary-gradient":"linear-gradient(45deg, #ffffff, #f8fafc)","--text-color":"#000000","--bubble-sent":"#000000","--bubble-received":"#00000","--background-color":"#ffffff"},black:{"--primary-color":"#111827","--primary-gradient":"linear-gradient(45deg, #1f2937, #374151)","--text-color":"#e5e7eb","--bubble-sent":"#4b5563","--bubble-received":"#1e293b","--background-color":"#0f172a"},orange:{"--primary-color":"#f97316","--primary-gradient":"linear-gradient(45deg, #f97316, #ea580c)","--text-color":"#000000","--bubble-sent":"#ea580c","--bubble-received":"#ffedd5","--background-color":"#fff7ed"},yellow:{"--primary-color":"#fbbf24","--primary-gradient":"linear-gradient(45deg, #fbbf24, #f59e0b)","--text-color":"#4b5563","--bubble-sent":"#f59e0b","--bubble-received":"#fef3c7","--background-color":"#fffbeb"},red:{"--primary-color":"#ef4444","--primary-gradient":"linear-gradient(45deg, #ef4444, #dc2626)","--text-color":"#00000","--bubble-sent":"#dc2626","--bubble-received":"#fee2e2","--background-color":"#fef2f2"},green:{"--primary-color":"#22c55e","--primary-gradient":"linear-gradient(45deg, #22c55e, #16a34a)","--text-color":"#1e293b","--bubble-sent":"#059669","--bubble-received":"#d1fae5","--background-color":"#f0fdf4"},blue:{"--primary-color":"#1e90ff","--primary-gradient":"linear-gradient(45deg, #1e90ff, #00bfff)","--text-color":"#333","--bubble-sent":"#007bff","--bubble-received":"#f1f5f9","--background-color":"#f5f7fa"}},a={};async function n(t){try{console.log(`Fetching bot config for tenant: ${t}`),console.log(`Request URL: ${e.apiEndpoint}/bot-config/${t}`);let r=await fetch(`${e.apiEndpoint}/bot-config/${t}`);if(console.log("Response status:",r.status),!r.ok){let a=await r.text();throw console.error("Error response:",a),Error(`Failed to fetch bot configuration: ${r.status}`)}let n=await r.json();if(console.log("Received config:",n),!n.bot_name||!n.welcome_message)throw Error("Invalid bot configuration: missing required fields");return n}catch(o){throw console.error("Error in fetchBotConfig:",o),o}}async function o(t){try{let r=await fetch(`${e.apiEndpoint}/bot-status/${t}`);if(!r.ok)throw Error("Failed to check bot status");let n=await r.json();return e.isActive="active"===n.status,e.isActive||a.chatContainer.classList.contains("lura-d-none")||c(),e.isActive}catch(o){return console.error("Error checking bot status:",o),!1}}async function i(t={}){let i=document.querySelector("script[data-tenant-id]"),l=i?.getAttribute("data-tenant-id");if(!l){console.error("No tenant ID provided");return}try{await o(l),setInterval(()=>o(l),e.statusCheckInterval);let s=await n(l);console.log("Full bot config received:",s),e.welcomeMessage=s.welcome_message,e.botName=s.bot_name;let p=s.color_theme?s.color_theme.toLowerCase():"blue";console.log("Normalized color theme:",p);let h=r[p]||r.blue;console.log("Using color theme:",p),console.log("Selected theme colors:",h);let b=document.createElement("style");b.textContent=`
                :root {
                    ${Object.entries(h).map(([e,t])=>`${e}: ${t};`).join("\n                ")}
                }
            `,document.head.appendChild(b),Object.assign(e,t),function e(){let t=document.createElement("style");if(t.textContent=`
            .lura-widget * {
                box-sizing: border-box;
            }
            .lura-widget p {
                margin: 0;
                padding: 0;
            }
            .lura-chat-icon {
                position: fixed;
                bottom: 75px;
                right: 17px;
                width: 50px;
                height: 50px;
                /* Remove default theme color */
                color: white;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                z-index: 999;
                transition: transform 0.3s ease;
            }
            .lura-chat-icon:hover {
                transform: scale(1.1);
            }
            .lura-chat-container {
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 350px;
                height: 500px;
                background: white;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                display: flex;
                flex-direction: column;
                overflow: hidden;
                z-index: 1000;
                transition: all 0.3s ease;
                border-radius: 10px;
                font-family: 'Poppins', sans-serif, Arial;
            }
            .lura-chat-button {
                background-color: var(--primary-color);
                border: none;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
                transition: background-color 0.3s ease;
                outline: none;
            }
            .lura-chat-button:focus {
                outline: none;
                box-shadow: none;
            }
            .lura-chat-button:hover {
                opacity: 0.9; /* Change from hardcoded color to use opacity */
            }
            .lura-chat-button svg {
                stroke: white;
            }
            .lura-chat-header {
                background: var(--primary-gradient);
                padding: 15px;
                color: white;
                display: flex;
                align-items: center;
                gap: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
            }
            .lura-chat-header strong {
                font-size: 20px;
                font-weight: 500;
                display: block;
                margin-bottom: 2px;
            }
            .lura-chat-header img {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                border: 2px solid white;
            }
            .lura-close-btn {
                background: transparent;
                border: none;
                color: white;
                font-size: 14px;
                padding: 5px 10px;
                cursor: pointer;
                margin-left: auto;
                outline: none;
            }
            .lura-close-btn:focus {
                outline: none;
                box-shadow: none;
            }
            .lura-chat-body {
                flex: 1;
                padding: 15px;
                overflow-y: auto;
                scrollbar-width: none;
                -ms-overflow-style: none;
                display: flex;
                flex-direction: column;
            }
            .lura-chat-body::-webkit-scrollbar {
                display: none;
            }
            .lura-chat-bubble {
                max-width: 80%;
                padding: 10px;
                opacity: 0;
                animation: lura-fadeInUp 0.5s ease-out forwards;
                border-radius: 12px;
                margin: 5px 0;
            }
            .lura-chat-bubble.sent {
                background: var(--bubble-sent);
                color: white;
                align-self: flex-end;
                margin-left: auto;
                font-size: 13px;
                border-bottom-right-radius: 0;
                word-wrap: break-word;
                overflow-wrap: break-word;
                white-space: normal;
            }
            .lura-chat-bubble.received {
                background: var(--bubble-received);
                color: var(--text-color);
                align-self: flex-start;
                text-align: left;
                font-size: 13px;
                border-top-left-radius: 0;
                overflow-wrap: break-word;
                word-wrap: break-word;
                word-break: break-word;
                max-width: 80%;
            }
            .lura-chat-bubble ol,
            .lura-chat-bubble ul {
                padding-left: 20px;
                margin: 5px 0;
            }
            .lura-chat-bubble li {
                margin-bottom: 3px;
            }
            .lura-chat-bubble p {
                margin-bottom: 8px;
            }
            .lura-chat-footer {
                display: flex;
                align-items: center;
                padding: 10px;
                border-top: 1px solid #ddd;
                position: relative;
                font-size: 13px;
            }
            .lura-chat-footer input {
                flex: 1;
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 10px;
                background: #f1f1f1;
                outline: none;
                font-family: 'Poppins', sans-serif, Arial;
            }
            .lura-send-button {
                background: var(--primary-color);
                border: none;
                color: white;
                border-radius: 10px;
                cursor: pointer;
                width: 40px;
                height: 40px;
                min-width: 40px;
                min-height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-left: 10px;
                position: relative;
                z-index: 10;
                transition: transform 0.2s ease;
            }
            .lura-send-button:hover {
                transform: scale(1.05);
            }
            .lura-typing-indicator {
                display: flex;
                align-items: center;
                padding: 8px 12px;
                background: #f1f1f1;
                border-radius: 15px;
                width: fit-content;
                margin-bottom: 8px;
                align-self: flex-start;
            }
            .lura-typing-indicator span {
                width: 6px;
                height: 6px;
                margin: 0 2px;
                background: gray;
                border-radius: 50%;
                display: inline-block;
                animation: lura-typing 1.2s infinite ease-in-out;
            }
            .lura-typing-indicator span:nth-child(1) {
                animation-delay: 0s;
            }
            .lura-typing-indicator span:nth-child(2) {
                animation-delay: 0.2s;
            }
            .lura-typing-indicator span:nth-child(3) {
                animation-delay: 0.4s;
            }
            .lura-ms-auto {
                margin-left: auto !important;
            }
            .lura-d-none {
                display: none !important;
            }
            @keyframes lura-typing {
                0% {
                    transform: translateY(0px);
                    opacity: 0.3;
                }
                50% {
                    transform: translateY(-5px);
                    opacity: 1;
                }
                100% {
                    transform: translateY(0px);
                    opacity: 0.3;
                }
            }
            @keyframes lura-fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            @media screen and (max-width: 480px) {
                .lura-chat-container {
                    width: 90%;
                    height: 80%;
                    bottom: 10%;
                    right: 5%;
                }
                .lura-chat-header strong {
                    font-size: 16px;
                }
                .lura-chat-header img {
                    width: 32px;
                    height: 32px;
                }
                .lura-chat-footer {
                    padding: 8px;
                }
                .lura-chat-footer input {
                    padding: 8px;
                    font-size: 14px;
                }
                .lura-send-button {
                    width: 36px;
                    height: 36px;
                    min-width: 36px;
                    min-height: 36px;
                }
                .lura-chat-bubble {
                    padding: 8px 12px;
                    font-size: 14px;
                }
            }
            .lura-status-bubble {
                position: fixed;
                bottom: 140px;
                right: 20px;
                background: var(--background-color);
                color: var(--text-color);
                padding: 15px 20px;
                border-radius: 10px;
                font-size: 14px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                animation: lura-fadeInUp 0.3s ease-out forwards;
                z-index: 1000;
                font-family: 'Poppins', sans-serif, Arial;
                max-width: 280px;
                display: flex;
                flex-direction: column;
                gap: 4px;  // Reduced from 8px
            }
            .lura-status-bubble h4 {
                margin: 0 0 2px;  // Added small bottom margin
                font-size: 15px;  // Added small bottom margin
                font-weight: 600;
                color: var(--text-color);
            }
            .lura-status-bubble p {
                margin: 0;
                font-size: 13px;
                line-height: 1.4;
                color: var(--text-color);
                opacity: 0.8;
            }
            .lura-status-bubble::before {
                content: '';
                position: absolute;
                bottom: -8px;
                right: 24px;
                width: 0;
                height: 0;
                border-left: 8px solid transparent;
                border-right: 8px solid transparent;
                border-top: 8px solid var(--background-color);
            }
            .lura-skip-button {
                background: transparent;
                border: 1px solid var(--primary-color);
                color: var(--primary-color);
                border-radius: 10px;
                padding: 8px 16px;
                margin-right: 8px;
                cursor: pointer;
                font-size: 13px;
                transition: all 0.2s ease;
            }
            .lura-skip-button:hover {
                background: var(--primary-color);
                color: white;
            }
        `,document.head.appendChild(t),!document.querySelector('link[href*="font-awesome"]')){let r=document.createElement("link");r.rel="stylesheet",r.href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css",document.head.appendChild(r)}if(!document.querySelector('link[href*="poppins"]')){let a=document.createElement("link");a.rel="stylesheet",a.href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap",document.head.appendChild(a)}}(),function t(){let r=document.createElement("div");r.className="lura-widget",document.body.appendChild(r);let a=document.createElement("div");a.className="lura-chat-icon",a.id="luraChatIcon",a.style.backgroundColor="var(--primary-color)",a.innerHTML=`
            <button class="lura-chat-button">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2z"></path>
                </svg>
            </button>`,r.appendChild(a);let n=document.createElement("div");n.className="lura-chat-container lura-d-none",n.id="luraChatContainer";let o=document.createElement("div");o.className="lura-chat-header",o.innerHTML=`
            <img src="${e.logoUrl}" alt="${e.botName}">
            <div>
                <strong id="botNameDisplay">${e.botName}</strong>
                <p style="font-size: 12px; opacity: 0.8;">We are online!</p>
            </div>
            <button class="lura-close-btn lura-ms-auto" id="luraCloseBtn">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
        `,n.appendChild(o);let i=document.createElement("div");i.className="lura-chat-body",i.id="luraChatBody",n.appendChild(i);let l=document.createElement("div");l.className="lura-chat-footer",l.innerHTML=`
            <input type="text" id="luraUserInput" placeholder="Enter your message...">
            <button class="lura-send-button" id="luraSendBtn">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 2L15 22L11 13L2 9L22 2Z"></path>
                </svg>
            </button>
        `,n.appendChild(l),r.appendChild(n)}(),a={chatIcon:document.getElementById("luraChatIcon"),chatContainer:document.getElementById("luraChatContainer"),chatBody:document.getElementById("luraChatBody"),userInput:document.getElementById("luraUserInput"),sendBtn:document.getElementById("luraSendBtn"),closeBtn:document.getElementById("luraCloseBtn")},a.chatIcon.addEventListener("click",d),a.closeBtn.addEventListener("click",c),a.sendBtn.addEventListener("click",_),a.userInput.addEventListener("keypress",function(e){"Enter"===e.key&&_()}),e.clearOnReload&&window.addEventListener("beforeunload",function(){f()}),a.chatBody.innerHTML="",u()}catch(g){console.error("Failed to initialize chat:",g);return}}function l(){let e=Date.now().toString(),r=p(t.pageLoadId,"");h(t.pageLoadId,e),r&&(f(),console.log("Page reloaded: Chat history cleared"))}async function s(){let r=null;try{let n=document.querySelector("script[data-tenant-id]"),o=n?.getAttribute("data-tenant-id");if(!o)throw Error("Tenant ID not found");r=x();let i=await fetch(`${e.apiEndpoint}/chat`,{method:"POST",headers:{"Content-Type":"application/json","X-Tenant-ID":o},body:JSON.stringify({type:"chat",tenant_id:o})});if(!i.ok)throw Error("Server error");let l=await i.json();l.user_id&&(h(t.userId,l.user_id),m("assistant",l.response),$("assistant",l.response))}catch(s){console.error("Error:",s),m("assistant",e.errorMessage)}finally{r&&C(r),a.userInput.disabled=!1,a.sendBtn.disabled=!1,a.userInput.focus()}}function d(){if(!e.isActive){let t=document.createElement("div");t.className="lura-status-bubble",t.innerHTML=`
                <h4>Training in Progress</h4>
                <p>The AI is still training with the data. Please wait a few minutes...</p>`,document.body.appendChild(t),setTimeout(()=>{t.parentNode===document.body&&t.remove()},3e3);return}a.chatContainer.classList.remove("lura-d-none"),a.chatIcon.classList.add("lura-d-none"),u(),setTimeout(()=>a.userInput.focus(),100)}function c(){a.chatContainer.classList.add("lura-d-none"),a.chatIcon.classList.remove("lura-d-none")}function u(){a.chatBody.innerHTML="";try{!function r(){let a=parseInt(p(t.lastActive,"0")),n=Date.now();n-a>e.inactivityTimeout&&f(),g()}();let r=b();(function e(t){t.forEach(e=>{let t=document.createElement("div");t.className=`lura-chat-bubble ${"user"===e.role?"sent":"received"}`,"user"===e.role?t.textContent=e.content:t.innerHTML=e.content,a.chatBody.appendChild(t)})})(r),y()}catch(n){console.error("Error loading chat history:",n),function t(){let r=document.createElement("div");r.className="lura-chat-bubble received",r.textContent=e.welcomeMessage,a.chatBody.appendChild(r),$("assistant",e.welcomeMessage)}()}}function p(e,t){try{let r=localStorage.getItem(e);return null===r?t:r}catch(a){return console.error("Error accessing localStorage:",a),t}}function h(e,t){try{return localStorage.setItem(e,t),!0}catch(r){return console.error("Error setting localStorage:",r),!1}}function b(){return JSON.parse(p(t.history,"[]"))}function f(){try{h(t.history,"[]"),h(t.initialized,"false")}catch(e){console.error("Error resetting chat history:",e)}}function g(){h(t.lastActive,Date.now().toString())}function $(e,r){try{let a=b();a.push({role:e,content:r}),h(t.history,JSON.stringify(a)),g()}catch(n){console.error("Error saving message:",n)}}function m(e,t){let r=document.createElement("div");if(r.className=`lura-chat-bubble ${"user"===e?"sent":"received"}`,"user"===e)r.textContent=t;else{r.innerHTML=t;let n=r.querySelector(".skip-name-link");n&&(n.onclick=e=>{e.preventDefault();let t=document.getElementById("luraUserInput");t.value="skip",_()})}return a.chatBody.appendChild(r),y(),r}function x(){let e=document.createElement("div");return e.className="lura-typing-indicator",e.innerHTML="<span></span><span></span><span></span>",a.chatBody.appendChild(e),y(),e}function y(){a.chatBody.scrollTop=a.chatBody.scrollHeight}function w(){let e=document.createElement("button");e.textContent="Skip",e.className="lura-skip-button",e.onclick=()=>{let e=document.getElementById("luraUserInput");e.value="skip",_()},a.chatFooter.insertBefore(e,a.sendBtn)}function v(){let e=document.querySelector(".lura-skip-button");e&&e.remove()}async function _(){let e=a.userInput.value.trim();if(""===e)return;a.userInput.disabled=!0,a.sendBtn.disabled=!0,m("user",e),$("user",e),a.userInput.value="";let t=x();await k(e,t)}async function k(t,r){try{let n=b(),o=document.querySelector("script[data-tenant-id]"),i=o?.getAttribute("data-tenant-id"),l=await fetch(`${e.apiEndpoint}/chat`,{method:"POST",headers:{"Content-Type":"application/json","X-Tenant-ID":i},body:JSON.stringify({message:t,history:n,tenant_id:i})});if(!l.ok)throw Error("Server error");let s=await l.json();r&&C(r);let d=m("assistant",s.response),c=d.querySelectorAll("a");c.forEach(e=>{e.getAttribute("target")||(e.setAttribute("target","_blank"),e.setAttribute("rel","noopener noreferrer"))}),$("assistant",s.response)}catch(u){console.error("Error:",u),C(r),m("assistant",e.errorMessage),$("assistant",e.errorMessage)}finally{a.userInput.disabled=!1,a.sendBtn.disabled=!1,a.userInput.focus()}}function C(e){e&&e.parentNode===a.chatBody&&a.chatBody.removeChild(e)}function E(t){if(!t)return;let r=document.querySelector(".lura-chat-header img");r&&(r.src=t,e.logoUrl=t)}return{init:i,setConfig:function(t){Object.assign(e,t),t.logoUrl&&E(t.logoUrl)},setLogo:E,setApiEndpoint:function(t){e.apiEndpoint=t},setWelcomeMessage:function(t){e.welcomeMessage=t},clearHistory:f,open:d,close:c,setClearOnReload:function(t){e.clearOnReload=t}}}();"loading"===document.readyState?document.addEventListener("DOMContentLoaded",()=>LuraChat.init()):LuraChat.init();