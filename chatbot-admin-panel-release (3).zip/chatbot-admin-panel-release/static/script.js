document.addEventListener('DOMContentLoaded', function() {
    let currentStep = 1;
    let selectedUrls = [];
    let processingStarted = false;
    let processingComplete = false;

    function updateProgress() {
        const progressBar = document.querySelector('.progress');
        if (progressBar) {
            progressBar.style.width = `${((currentStep - 1) / 3) * 100}%`;
        }
        document.querySelectorAll('.step').forEach((step, index) => {
            step.classList.toggle('active', index < currentStep);
        });
    }

    function showStep(step) {
        document.querySelectorAll('.step-view').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(typeof step === 'number' ? `step${step}` : step).classList.remove('hidden');
        if (typeof step === 'number') {
            currentStep = step;
            updateProgress();
        }

        if (step === 5 || step === 'deployment') {
            showDeploymentSection();
        }
    }

    document.getElementById('urlForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const websiteUrl = document.getElementById('websiteUrl').value;
        const extractionProgress = document.getElementById('extractionProgress');
        if (extractionProgress) extractionProgress.classList.remove('hidden');
        
        try {
            const response = await fetch('/extract_urls', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ website_url: websiteUrl })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            displayUrls(data.urls);
            showStep(2);
        } catch (error) {
            showMessage('Error', 'Error extracting URLs: ' + error.message);
        } finally {
            if (extractionProgress) extractionProgress.classList.add('hidden');
        }
    });

    function displayUrls(urls) {
        const urlList = document.getElementById('urlList');
        urlList.innerHTML = urls.map(url => `
            <div class="url-item">
                <input type="checkbox" value="${url}" id="url_${url.replace(/[^a-zA-Z0-9]/g, '_')}" checked>
                <label for="url_${url.replace(/[^a-zA-Z0-9]/g, '_')}">${url}</label>
            </div>
        `).join('');
        updateSelectedCount();
    }

    function updateSelectedCount() {
        selectedUrls = Array.from(document.querySelectorAll('#urlList input:checked')).map(cb => cb.value);
        const selected = selectedUrls.length;
        const total = document.querySelectorAll('#urlList input[type="checkbox"]').length;
        document.getElementById('proceedButton').disabled = selected === 0;
        const selectionCount = document.getElementById('selectionCount');
        if (selectionCount) {
            selectionCount.textContent = `Selected: ${selected}/${total}`;
        }
    }

    // Define selection functions at top level
    window.selectAll = function() {
        document.querySelectorAll('#urlList input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateSelectedCount();
    };

    window.deselectAll = function() {
        document.querySelectorAll('#urlList input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateSelectedCount();
    };

    window.selectVisible = function() {
        document.querySelectorAll('.url-item:not([style*="display: none"]) input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateSelectedCount();
    };

    window.deselectVisible = function() {
        document.querySelectorAll('.url-item:not([style*="display: none"]) input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateSelectedCount();
    };

    // Update search functionality to properly show/hide items
    document.getElementById('urlSearch').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        document.querySelectorAll('.url-item').forEach(item => {
            const url = item.querySelector('label').textContent.toLowerCase();
            item.style.display = url.includes(searchTerm) ? 'flex' : 'none';
        });
    });

    // Fix proceedToBot function
    function proceedToBot() {
        if (selectedUrls.length > 0) {
            showStep(3);
        } else {
            showMessage('Warning', 'Please select at least one URL to proceed.');
        }
    }

    // Add proper event listener
    document.querySelector('#proceedButton').addEventListener('click', proceedToBot);

    // Remove the window binding since we're using direct event listener
    document.getElementById('urlList').addEventListener('change', function() {
        updateSelectedCount();
        document.getElementById('proceedButton').disabled = selectedUrls.length === 0;
    });

    document.getElementById('botConfigForm').addEventListener('submit', function(e) {
        e.preventDefault();
        showStep(4);
    });

    document.getElementById('companyForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        try {
            // Show processing modal with initial message
            showProcessingModal('Initializing your chatbot...');
            const directoryId = await saveCompanyDetails();
            
            // Start processing in background without awaiting
            startProcessing(directoryId).catch(error => {
                console.error('Background processing error:', error);
            });

            // Keep the modal visible for full 30 seconds
            let timeLeft = 30;
            const interval = setInterval(() => {
                timeLeft--;
                updateProcessingModal(`Processing your data... ${timeLeft}s remaining`);
                
                if (timeLeft <= 0) {
                    clearInterval(interval);
                    hideProcessingModal();
                    showStep(5);
                }
            }, 1000);

        } catch (error) {
            console.error('Error:', error);
            hideProcessingModal();
            showMessage('Error', 'Failed to initialize chatbot: ' + error.message);
        }
    });

    function showMessage(title, message) {
        const modal = document.createElement('div');
        modal.className = 'message-modal';
        modal.innerHTML = `
            <div class="message-content">
                <h3>${title}</h3>
                <p>${message}</p>
                <button onclick="this.closest('.message-modal').remove()" class="primary-button">
                    OK
                </button>
            </div>
        `;
        document.body.appendChild(modal);
    }

    // Helper functions for processing modal
    function showProcessingModal(message) {
        const modal = document.getElementById('processingModal');
        const text = document.getElementById('processingModalText');
        if (modal && text) {
            text.textContent = message || 'Processing...';
            modal.classList.remove('hidden');
        }
    }
    function updateProcessingModal(message) {
        const text = document.getElementById('processingModalText');
        if (text) text.textContent = message;
    }
    function hideProcessingModal() {
        const modal = document.getElementById('processingModal');
        if (modal) modal.classList.add('hidden');
    }

    async function startProcessing(directoryId) {
        try {
            const response = await fetch('/process_urls', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory_id: directoryId })
            });

            const result = await response.json();
            if (!result.success) {
                console.error('Processing failed:', result.error);
            }

        } catch (error) {
            console.error('Background processing error:', error);
        }
    }

    async function saveCompanyDetails() {
        const submitButton = document.querySelector('#companyForm button[type="submit"]');
        submitButton.disabled = true;

        try {
            const data = {
                bot_name: document.getElementById('botName').value,
                welcome_message: document.getElementById('welcomeMessage').value,
                bot_description: document.getElementById('botDescription').value,
                color_theme: document.getElementById('colorTheme').value,
                company_name: document.getElementById('companyName').value,
                company_address: document.getElementById('companyAddress').value,
                company_description: document.getElementById('companyDescription').value,
                about_us: document.getElementById('aboutUs').value,
                linkedin: document.getElementById('linkedIn').value,
                facebook: document.getElementById('facebook').value,
                terms_url: document.getElementById('termsUrl').value,
                privacy_policy_url: document.getElementById('privacyPolicyUrl').value,
                pricing_url: document.getElementById('pricingUrl').value,
                contact_email: document.getElementById('contactEmail').value,
                contact_number: document.getElementById('contactNumber').value,
                website_url: document.getElementById('websiteUrl').value,
                selected_urls: selectedUrls
            };

            const response = await fetch('/save_user_data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.error || 'Failed to save configuration');
            }

            window._tenant_id = result.tenant_id;
            return result.directory_id;

        } catch (error) {
            showMessage('Error', error.message);
            throw error;
        } finally {
            submitButton.disabled = false;
            // Remove the hideProcessingModal call from here
        }
    }

    // --- Deployment Section ---
    function showDeploymentSection() {
        const deploymentSection = document.getElementById('step5');
        if (deploymentSection) {
            deploymentSection.classList.remove('hidden');
            const codeElem = document.getElementById('deploy-script-code');
            const copyBtn = document.getElementById('copy-deploy-script');
            const feedback = document.getElementById('copy-feedback');

            if (codeElem && window._tenant_id) {
                const scriptTag = `<script src="http://127.0.0.1:5001/static/chatbot.js" data-tenant-id="${window._tenant_id}"><\/script>`;
                codeElem.textContent = scriptTag;

                if (copyBtn) {
                    copyBtn.onclick = async function() {
                        try {
                            await navigator.clipboard.writeText(scriptTag);
                            feedback.classList.add('show');
                            setTimeout(() => {
                                feedback.classList.remove('show');
                            }, 2000);
                        } catch (err) {
                            console.error('Failed to copy:', err);
                        }
                    };
                }
            }
        }
    }

    // Update selection functions and add event listeners
    document.getElementById('selectAllBtn').addEventListener('click', function() {
        document.querySelectorAll('#urlList input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateSelectedCount();
    });

    document.getElementById('deselectAllBtn').addEventListener('click', function() {
        document.querySelectorAll('#urlList input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateSelectedCount();
    });

    document.getElementById('selectVisibleBtn').addEventListener('click', function() {
        document.querySelectorAll('.url-item:not([style*="display: none"]) input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateSelectedCount();
    });

    document.getElementById('deselectVisibleBtn').addEventListener('click', function() {
        document.querySelectorAll('.url-item:not([style*="display: none"]) input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateSelectedCount();
    });

    // Update search functionality to properly show/hide items
    document.getElementById('urlSearch').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        document.querySelectorAll('.url-item').forEach(item => {
            const label = item.querySelector('label');
            const url = label.textContent.toLowerCase();
            item.style.display = url.includes(searchTerm) ? 'flex' : 'none';
        });
    });

    // Initialize the form
    updateProgress();
});
