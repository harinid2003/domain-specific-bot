import logging
import weaviate
from weaviate.classes.init import Auth
import google.generativeai as genai
from api_info import weaviate_api_key, weaviate_url, gemini_api_key
import atexit

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)

# Configure Gemini
genai.configure(api_key=gemini_api_key)

# Initialize Weaviate client
try:
    client = weaviate.connect_to_weaviate_cloud(
        cluster_url=weaviate_url,
        auth_credentials=Auth.api_key(weaviate_api_key),
        headers={"X-Google-Api-Key": gemini_api_key}
    )
    logger.info("Connected to Weaviate successfully.")
except Exception as e:
    logger.error(f"Failed to connect to Weaviate: {e}")
    client = None

if 'client' in globals() and client is not None:
    atexit.register(client.close)

def get_embedding(text: str) -> list:
    """Generate embeddings using Gemini's text-embedding-004"""
    text = text.replace("\n", " ")
    try:
        result = genai.embed_content(
            model="models/text-embedding-004",
            content=text,
            task_type="RETRIEVAL_QUERY"
        )
        return result["embedding"]
    except Exception as e:
        logger.error(f"Error generating embedding: {e}")
        return []

def get_weaviate_search_context(query: str, max_results: int = 3, collection_name: str = "Document") -> str:
    """Get search context using Weaviate vector search"""
    if client is None:
        return "Weaviate connection unavailable."

    try:
        collection = client.collections.get(collection_name)
        response = collection.query.near_text(
            query=query, 
            limit=max_results
        )

        if response.objects:
            return "\n\n###\n\n".join(
                [obj.properties.get("content", "") for obj in response.objects]
            )
        return "No relevant context found."
    except Exception as e:
        logger.error(f"Weaviate search error: {e}")
        return "Error retrieving context."

def get_completion_from_messages(question, model="gemini-1.5-flash", temperature=0, conversation_history=None,
                               collection_name=None, system_message=None):
    """Get completion using Gemini 1.5 Flash"""
    try:
        # Get context from vector search
        context = get_weaviate_search_context(question, collection_name=collection_name)
        
        # Format conversation into a single prompt for Flash model
        prompt_parts = []
        
        if system_message:
            prompt_parts.append(f"System: {system_message}\n")
            
        if conversation_history:
            for msg in conversation_history:
                role = "User" if msg["role"] == "user" else "Assistant"
                prompt_parts.append(f"{role}: {msg['content']}\n")
        
        # Add context and question
        prompt = f"""Background Context: {context}

Previous Conversation:
{''.join(prompt_parts)}

Current Question: {question}

Please provide a concise and relevant response based on the context and conversation history."""

        # Initialize Gemini Flash model
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Generate response with Flash model optimizations
        response = model.generate_content(
            prompt,
            generation_config=genai.types.GenerationConfig(
                temperature=temperature,
                top_p=0.9,
                top_k=40,
                max_output_tokens=1024  # Flash model works best with controlled output length
            ),
            safety_settings=[
                {
                    "category": "HARM_CATEGORY_HARASSMENT",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    "category": "HARM_CATEGORY_HATE_SPEECH",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE"
                }
            ]
        )
        
        return response.text

    except Exception as e:
        logger.error(f"Error in get_completion_from_messages: {str(e)}")
        raise

if __name__ == "__main__":
    logger.info("Retrieval chatbot module loaded successfully.")
