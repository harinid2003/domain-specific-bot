import os
import atexit
import logging
from pymongo import MongoClient
from pymongo.server_api import ServerApi
from datetime import datetime, timezone
from bson import ObjectId
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logger = logging.getLogger(__name__)

# Initialize MongoDB connection
client = None
db = None
collection = None

try:
    # Get MongoDB URI from environment variable or use default
    uri = os.getenv('MONGODB_URI')
    if not uri:
        uri = "mongodb://localhost:27017/chatbot"  # Default fallback URI
        logger.warning(f"MONGODB_URI not set, using default: {uri}")
    
    # Initialize client with retry and timeout options
    client = MongoClient(
        uri,
        server_api=ServerApi('1'),
        serverSelectionTimeoutMS=5000,
        connectTimeoutMS=5000
    )
    
    # Test connection
    client.admin.command('ping')
    
    # Initialize database and collection
    db = client.get_database()
    collection = db.tenants if db else None
    
    logger.info("Successfully connected to MongoDB")
    
except Exception as e:
    logger.error(f"MongoDB connection error: {str(e)}")
    if client:
        client.close()
        client = None
    db = None
    collection = None

def cleanup():
    """Cleanup MongoDB connection"""
    global client, db, collection
    if client:
        client.close()
        client = None
        db = None
        collection = None
        logger.info("MongoDB connection closed")

atexit.register(cleanup)

# Add new collection
users = db["users"] if db else None

def insert_tenant(data):
    """Insert tenant data with string _id"""
    try:
        # Generate string ID
        str_id = str(ObjectId())
        
        # Add the string ID to the data before insertion
        data = {
            '_id': str_id,
            **data  # Spread the rest of the data
        }
        
        # Insert document with string ID
        db.tenants.insert_one(data)
        
        return str_id

    except Exception as e:
        logging.error(f"Error inserting tenant: {e}")
        return None

def get_tenant(tenant_id):
    """Get tenant data by string ID"""
    try:
        # Search directly by string ID
        tenant = db.tenants.find_one({"_id": tenant_id})
        return tenant
    except Exception as e:
        logging.error(f"Error getting tenant: {e}")
        return None

def get_tenant_by_id(tenant_id):
    """Get tenant by ID with error handling"""
    if not collection:
        logger.error("MongoDB collection not available")
        return None
        
    try:
        return collection.find_one({
            "_id": ObjectId(tenant_id),
            "updated_at": {"$lt": datetime.now(timezone.utc)}
        })
    except Exception as e:
        logger.error(f"Error fetching tenant: {str(e)}")
        return None

def update_tenant_status(tenant_id, status):
    """Update tenant status using string ID"""
    try:
        result = db.tenants.update_one(
            {"_id": tenant_id},
            {"$set": {"status": status}}
        )
        return result.modified_count > 0
    except Exception as e:
        logging.error(f"Error updating tenant status: {e}")
        return False

def update_tenant_results(tenant_id, results):
    """Update tenant results using string ID"""
    try:
        result = db.tenants.update_one(
            {"_id": tenant_id},
            {"$set": {
                "processing_results": results,
                "processed_at": datetime.now(timezone.utc).isoformat()
            }}
        )
        return result.modified_count > 0
    except Exception as e:
        logging.error(f"Error updating tenant results: {e}")
        return False

def create_user(tenant_id: str) -> str:
    """Create a new anonymous user and return the user_id"""
    try:
        now = datetime.now(timezone.utc).isoformat()
        user_data = {
            "_id": str(ObjectId()),
            "tenant_id": tenant_id,
            "created_at": now,
            "last_active": now
        }
        
        result = users.insert_one(user_data)
        if result.inserted_id:
            return user_data["_id"]
        return None
        
    except Exception as e:
        logging.error(f"Error creating user: {e}")
        return None

def update_user_last_active(user_id: str):
    """Update user's last active timestamp"""
    try:
        users.update_one(
            {"_id": user_id},
            {"$set": {"last_active": datetime.now(timezone.utc).isoformat()}}
        )
    except Exception as e:
        logging.error(f"Error updating user last active: {e}")

def get_user(user_id: str):
    """Get user by ID"""
    try:
        return users.find_one({"_id": user_id})
    except Exception as e:
        logging.error(f"Error getting user: {e}")
        return None

