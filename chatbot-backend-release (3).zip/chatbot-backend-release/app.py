import logging
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from vector_search import get_completion_from_messages
import markdown
import re
from bson import ObjectId
import mongodb
import atexit
from typing import Dict
import google.generativeai as genai
from api_info import gemini_api_key

import warnings
warnings.filterwarnings('ignore')

# Configure Gemini
genai.configure(api_key=gemini_api_key)

# Configure logging with a file handler that will be properly closed
log_file_handler = logging.FileHandler("chatbot.log")
stream_handler = logging.StreamHandler()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[log_file_handler, stream_handler]
)

# Register handler closing on exit
atexit.register(log_file_handler.close)

logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Markdown extensions for enhanced rendering
MARKDOWN_EXTENSIONS = [
    "markdown.extensions.fenced_code",
    "markdown.extensions.tables",
    "markdown.extensions.nl2br",
    "markdown.extensions.sane_lists",
    "markdown.extensions.smarty",
    "markdown.extensions.codehilite",
    "markdown.extensions.meta",
]

# Add global cache
BOT_CONFIGS: Dict[str, dict] = {}

def sanitize_message_content(content, role):
    if role == "user" and "<" in content and ">" in content:
        content = re.sub(r"<[^>]*>", "", content)
    return content.strip()


def convert_markdown_to_html(markdown_text):
    try:
        # Preprocessing to handle different list styles
        lines = markdown_text.split('\n')
        processed_lines = []
        for line in lines:
            # Handle bullet points
            if line.strip().startswith(('- ', '• ')):
                # Normalize to bullet point (•)
                line = line.replace('- ', '• ')

            # Preserve original line if no special processing needed
            processed_lines.append(line)

        # Rejoin the lines
        processed_markdown = '\n'.join(processed_lines)

        # Convert to HTML with comprehensive extensions
        html = markdown.markdown(
            processed_markdown,
            extensions=MARKDOWN_EXTENSIONS,
            output_format="html5"
        )

        # Post-processing to add target="_blank" to all links
        def add_link_attributes(match):
            # Original link tag
            original_link = match.group(0)

            # Check if target and rel attributes already exist
            if 'target=' in original_link or 'rel=' in original_link:
                return original_link

            # Insert target and rel attributes before closing '>'
            modified_link = original_link.replace('>', ' target="_blank" rel="noopener noreferrer">')
            return modified_link

        # Use regex to modify <a> tags
        html = re.sub(r'<a\s+href=[^>]+>', add_link_attributes, html)

        # Additional post-processing
        # Replace bullet point character with HTML entity if required
        html = html.replace('• ', '&#8226; ')

        return html
    except Exception as e:
        logger.error(f"Markdown conversion error: {e}")
        return f"<p>Error processing response: {str(e)}</p>"


def is_short_query(message):
    """Determine if a user message is a short query that needs special handling"""
    message = message.lower().strip()

    # Define common short queries that need context
    short_queries = [
        "services", "products", "features", "pricing", "cost", "benefits",
        "advantages", "how", "integration", "requirements", "support",
        "documentation", "jobs", "careers", "openings", "apply", "salary",
        "testimonials", "case studies", "examples", "demo", "about", "contact",
        "locations", "offices", "team", "clients", "partners"
    ]

    # Check if the message is a single word or very short phrase
    words = message.split()
    if len(words) <= 2 and (message in short_queries or words[0] in short_queries):
        return True

    return False


def load_bot_config(tenant_id: str) -> dict:
    """Load and cache bot configuration"""
    if tenant_id in BOT_CONFIGS:
        return BOT_CONFIGS[tenant_id]
    
    try:
        tenant = mongodb.get_tenant_by_id(tenant_id)
        if not tenant:
            logger.error(f"Tenant not found: {tenant_id}")
            return {}
            
        config = {
            "bot_name": tenant.get("bot_name"),
            "welcome_message": tenant.get("welcome_message"),
            "bot_instructions": tenant.get("bot_instructions"),
            "color_theme": tenant.get("color_theme", "blue")
        }
        
        BOT_CONFIGS[tenant_id] = config
        return config
        
    except Exception as e:
        logger.error(f"Error loading bot config: {e}")
        return {}


@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.json
        logger.info(f"Received chat request: {data}")

        if not data or not data.get("message"):
            logger.error("Invalid request: No message received")
            return jsonify({"response": "Invalid request - message required"}), 400

        tenant_id = request.headers.get('X-Tenant-ID') or data.get('tenant_id')
        if not tenant_id:
            logger.error("No tenant ID provided")
            return jsonify({"response": "Tenant ID is required"}), 400

        # Load config
        config = load_bot_config(tenant_id)
        if not config:
            logger.error(f"Bot config not found for tenant: {tenant_id}")
            return jsonify({"response": "Bot configuration not found"}), 404

        try:
            collection_name = f"tenant_{tenant_id}"
            user_message = data["message"]
            chat_history = data.get("history", [])

            # Format history
            formatted_history = [
                {
                    "role": msg["role"],
                    "content": sanitize_message_content(msg["content"], msg["role"]),
                }
                for msg in chat_history[:]
                if msg["role"] in ["user", "assistant"]
            ]

            # Get AI response
            response = get_completion_from_messages(
                question=user_message,
                model="gpt-3.5-turbo",
                temperature=0,
                conversation_history=formatted_history,
                collection_name=collection_name,
                system_message=config.get("bot_instructions", "")
            )

            # Convert to HTML and return
            html_response = convert_markdown_to_html(response)
            logger.info(f"Successfully processed message. Message: {user_message[:50]}...")
            
            return jsonify({
                "success": True,
                "response": html_response
            })

        except Exception as e:
            logger.error(f"Error processing chat message: {str(e)}")
            return jsonify({
                "success": False,
                "response": "Sorry, I encountered an error processing your message."
            }), 500

    except Exception as e:
        logger.error(f"Unexpected error in chat endpoint: {str(e)}")
        return jsonify({
            "success": False,
            "response": "An unexpected error occurred. Please try again."
        }), 500


# Add cleanup on shutdown
def cleanup():
    if 'client' in globals() and client is not None:
        client.close()

atexit.register(cleanup)


@app.route("/bot-config/<tenant_id>", methods=["GET"])
def get_bot_config(tenant_id):
    """
    Fetch bot configuration based on tenant_id
    """
    try:
        if not ObjectId.is_valid(tenant_id):
            return jsonify({"error": "Invalid tenant ID format"}), 400
            
        config = load_bot_config(tenant_id)
        if not config:
            return jsonify({"error": "Tenant not found"}), 404
            
        # Return only what the frontend needs
        return jsonify({
            "bot_name": config["bot_name"],
            "welcome_message": config["welcome_message"],
            "color_theme": config["color_theme"]
        })

    except Exception as e:
        logger.error(f"Error fetching bot config: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


@app.route("/bot-status/<tenant_id>", methods=["GET"])
def get_bot_status(tenant_id):
    """
    Check if the bot is active for the given tenant
    """
    try:
        if not ObjectId.is_valid(tenant_id):
            return jsonify({"error": "Invalid tenant ID format"}), 400
        
        # Query MongoDB for tenant status
        tenant = mongodb.get_tenant_by_id(tenant_id)
        
        if not tenant:
            return jsonify({"error": "Tenant not found"}), 404

        return jsonify({
            "status": "active" if tenant.get("status") == "active" else "inactive"
        })

    except Exception as e:
        logger.error(f"Error checking bot status: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


@app.route('/static/chatbot.js')
def serve_chatbot_js():
    return send_from_directory('static', 'chatbot.js')


@app.errorhandler(404)
def not_found(error):
    return (
        jsonify(
            {"error": "Not Found", "message": "The requested endpoint does not exist."}
        ),
        404,
    )


@app.errorhandler(500)
def server_error(error):
    logger.error(f"Server error: {error}")
    return (
        jsonify(
            {
                "error": "Internal Server Error",
                "message": "Something went wrong on our end.",
            }
        ),
        500,
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=False)  # Make sure port matches CONFIG.apiEndpoint