# Chatbot Backend

A Flask-based backend service for an AI-powered chatbot with multi-tenant support and vector search capabilities.

## Features

- Multi-tenant support with isolated chat contexts
- Vector search using Weaviate for relevant context retrieval
- OpenAI integration for intelligent responses
- MongoDB integration for tenant configuration storage
- Markdown to HTML conversion for formatted responses
- CORS support for cross-origin requests
- Comprehensive error handling and logging

## Prerequisites

- Python 3.8+
- MongoDB
- Weaviate Cloud Account
- OpenAI API Key
- Langchain API Key

## Installation

1. Clone the repository:
```bash
git clone https://gitlab.aaludradevelopers.com/ai_ml/rag-chatbot/chatbot-backend.git
cd chatbot-backend
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure API keys:
Create or modify `api_info.py` with your credentials:
```python
gemini_api_key="your_gemini_api_key"
openai_api_key="your_openai_api_key"
weaviate_api_key="your_weaviate_api_key"
weaviate_url="your_weaviate_url"
mongodb_uri="your_mongodb_uri"
langchain_api_key="your_langchain_api_key"
```

## Usage

1. Start the server:
```bash
python app.py
```

The server will run on `http://0.0.0.0:5002` by default.

## API Endpoints

### Chat Endpoint
- **POST** `/chat`
- Requires `X-Tenant-ID` header
- Request body:
```json
{
    "message": "user message",
    "history": [
        {"role": "user", "content": "previous message"},
        {"role": "assistant", "content": "previous response"}
    ]
}
```

### Bot Configuration
- **GET** `/bot-config/<tenant_id>`
- Returns bot name, welcome message, and color theme

### Bot Status
- **GET** `/bot-status/<tenant_id>`
- Returns bot active/inactive status

## Architecture

- `app.py`: Main Flask application and routing
- `vector_search.py`: Weaviate integration and vector search functionality
- `api_info.py`: API keys and configuration
- Static files served from `/static` directory

## Error Handling

The application includes comprehensive error handling:
- Invalid requests
- Missing tenant IDs
- Database connection issues
- Vector search failures
- Markdown conversion errors

## Logging

Logs are written to `chatbot.log` with both file and stream handlers.

## Security

- API keys are stored separately in `api_info.py`
- CORS enabled for cross-origin requests
- Tenant isolation through MongoDB collections
- Input sanitization for user messages

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a merge request

## License

Proprietary - All rights reserved

## Support

Contact the development team for support and feature requests.
